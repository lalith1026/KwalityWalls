﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kwality.Library.Model
{
    public class AdminEntity
    { 
        public String AdminName { get; set; }
        public String  EmailID { get; set; }
        public String Password { get; set; }
        public String Usertype { get; set; }
        public String FullName { get; set; }
        public String Designation { get; set; }
        public String VerificationCode { get; set; }
    }
  
    
}
