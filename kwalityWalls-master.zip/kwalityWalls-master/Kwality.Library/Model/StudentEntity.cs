﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kwality.Library.Model
{
    public class StudentEntity: BaseEntity
    {
        
        public int Choco { get; set; }
        public int Vanilla { get; set; }

    }
}
