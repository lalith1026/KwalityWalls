﻿namespace Kwality.Library.Repository
{
    public class ActionResult
    {
    }
}