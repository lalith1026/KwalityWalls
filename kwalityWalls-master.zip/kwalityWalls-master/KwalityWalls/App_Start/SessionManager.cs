﻿using Kwality.Library.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

namespace KwalityWalls.App_Start
{
    public class SessionManager
    {
        //private static string  LoggedUserKey="LoggedUserKey";
        //public UserEntity GetSession()
        //{
        //    //Session
        //}
        //public SetSession(UserEntity LoggedUser)
        //{

        //}
    }
}