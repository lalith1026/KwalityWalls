﻿using System.Web.UI;

namespace KwalityWalls.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}